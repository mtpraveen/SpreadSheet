public class QuickStartDao {

}
