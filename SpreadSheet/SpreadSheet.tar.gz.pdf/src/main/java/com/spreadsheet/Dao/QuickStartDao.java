package com.spreadsheet.Dao;

import com.spreadsheet.model.QuickStartDto;

public interface QuickStartDao {
	
	public void saveData(QuickStartDto qsDto) ;
}
